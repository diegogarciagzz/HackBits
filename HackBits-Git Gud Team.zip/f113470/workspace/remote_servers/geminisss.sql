prompt --workspace/remote_servers/geminisss
begin
--   Manifest
--     REMOTE SERVER: geminisss
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38480805229426179952
,p_default_application_id=>113470
,p_default_id_offset=>0
,p_default_owner=>'WKSP_GITGUDHACKMTY'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(38781178789264278757)
,p_name=>'geminisss'
,p_static_id=>'geminiss'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('geminiss'),'https://api.gemini.google.com/v1')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('geminiss'),'')
,p_server_type=>'GENERATIVE_AI'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('geminiss'),'')
,p_credential_id=>wwv_flow_imp.id(38781178496401278756)
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('geminiss'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('geminiss'),'')
,p_prompt_on_install=>true
,p_ai_provider_type=>'OPENAI'
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('geminiss'),'gpt-4o')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('geminiss'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('geminiss'),'')
);
wwv_flow_imp.component_end;
end;
/
