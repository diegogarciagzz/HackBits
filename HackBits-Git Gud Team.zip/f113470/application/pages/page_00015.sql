prompt --application/pages/page_00015
begin
--   Manifest
--     PAGE: 00015
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38480805229426179952
,p_default_application_id=>113470
,p_default_id_offset=>0
,p_default_owner=>'WKSP_GITGUDHACKMTY'
);
wwv_flow_imp_page.create_page(
 p_id=>15
,p_name=>'Calendar view'
,p_alias=>'CALENDAR-VIEW'
,p_step_title=>'Calendar view'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'body {',
'    background-image: url("#APP_FILES#fondo_negro2.jpg");',
unistr('    background-size: cover; /* Ajusta el tama\00F1o de la imagen para cubrir toda la pantalla */'),
'    background-position: center; /* Centra la imagen */',
'    background-repeat: no-repeat; /* Evita que la imagen se repita */',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'08'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38855952195966377477)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38680107773328837048)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(38679791983919836998)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(38680170606298837076)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38855952804961377478)
,p_plug_name=>'Calendar view'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38680095302045837042)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'TASKS_HABITS'
,p_include_rowid_column=>false
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'additional_calendar_views', 'list:navigation',
  'display_column', 'TITULO',
  'end_date_column', 'FECHA_FINAL',
  'event_sorting', 'AUTOMATIC',
  'maximum_events_day', '10',
  'multiple_line_event', 'Y',
  'show_time', 'N',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'FECHA_INICIO',
  'view_edit_link', 'f?p=&APP_ID.:32:&SESSION.::&DEBUG.::P32_TASK_ID:&TASK_ID.')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38444468468429283750)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38855952804961377478)
,p_button_name=>'AddTask'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--primary:t-Button--simple:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(38680169135582837075)
,p_button_image_alt=>'Add Habit'
,p_button_redirect_url=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:::'
,p_grid_new_row=>'Y'
);
wwv_flow_imp.component_end;
end;
/
