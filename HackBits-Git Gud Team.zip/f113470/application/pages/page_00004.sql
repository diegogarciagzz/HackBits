prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38480805229426179952
,p_default_application_id=>113470
,p_default_id_offset=>0
,p_default_owner=>'WKSP_GITGUDHACKMTY'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Timeline'
,p_alias=>'ANALYTICS'
,p_step_title=>'Analytics'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'body {',
'    background-image: url("#APP_FILES#fondo_negro2.jpg");',
unistr('    background-size: cover; /* Ajusta el tama\00F1o de la imagen para cubrir toda la pantalla */'),
'    background-position: center; /* Centra la imagen */',
'    background-repeat: no-repeat; /* Evita que la imagen se repita */',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'04'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38674675947735705343)
,p_plug_name=>'TIMELINE'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38680095302045837042)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_ajax_items_to_submit=>'P1_TIME_PERIOD'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(38674676055818705344)
,p_region_id=>wwv_flow_imp.id(38674675947735705343)
,p_chart_type=>'area'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(38674676108451705345)
,p_chart_id=>wwv_flow_imp.id(38674676055818705344)
,p_seq=>10
,p_name=>'DATA'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    CASE ',
'        WHEN :P1_TIME_PERIOD = ''Weekly'' THEN TO_CHAR(DATE_, ''YYYY-MM-DD'') -- Show individual dates',
'        WHEN :P1_TIME_PERIOD = ''Monthly'' THEN TO_CHAR(DATE_, ''YYYY-MM-DD'') -- Show individual dates',
'        WHEN :P1_TIME_PERIOD = ''Yearly'' THEN TO_CHAR(TRUNC(DATE_, ''MM''), ''YYYY-MM'') -- Group by month for the current year',
'        WHEN :P1_TIME_PERIOD = ''All Time'' THEN TO_CHAR(TRUNC(DATE_, ''MM''), ''YYYY-MM'') -- Group by month for the current year',
'    END AS x_period,',
'    ROUND(SUM(VALUE), 2) AS y_total',
'',
'FROM',
'    RANDOM_DATA_BIYEARLY',
'',
'WHERE',
'    DATE_ IS NOT NULL',
'    AND (',
'        :P1_ALL_TIME = ''TRUE'' ',
'        OR',
'        -- Only show the last 7 days if "Weekly" is selected',
'        (:P1_TIME_PERIOD = ''Weekly'' AND :P1_ALL_TIME IS NULL AND DATE_ >= TRUNC(SYSDATE) - 6 AND DATE_ <= TRUNC(SYSDATE))',
'        OR',
'        -- Only show the last 30 days if "Monthly" is selected',
'        (:P1_TIME_PERIOD = ''Monthly'' AND DATE_ >= TRUNC(SYSDATE) - 29 AND DATE_ <= TRUNC(SYSDATE))',
'        OR',
'        -- Only show the data for the current year if "Yearly" is selected',
'        (:P1_TIME_PERIOD = ''Yearly'' AND TO_CHAR(DATE_, ''YYYY'') = TO_CHAR(SYSDATE, ''YYYY''))',
'        OR',
'        :P1_TIME_PERIOD = ''All Time''',
'    )',
'GROUP BY',
'    CASE ',
'        WHEN :P1_TIME_PERIOD = ''Weekly'' THEN TO_CHAR(DATE_, ''YYYY-MM-DD'') -- Group by individual date',
'        WHEN :P1_TIME_PERIOD = ''Monthly'' THEN TO_CHAR(DATE_, ''YYYY-MM-DD'') -- Group by individual date',
'        WHEN :P1_TIME_PERIOD = ''Yearly'' THEN TO_CHAR(TRUNC(DATE_, ''MM''), ''YYYY-MM'') -- Group by month for the current year',
'        WHEN :P1_TIME_PERIOD = ''All Time'' THEN TO_CHAR(TRUNC(DATE_, ''MM''), ''YYYY-MM'') -- Group by month for the current year',
'    END',
'ORDER BY',
'    x_period;',
''))
,p_ajax_items_to_submit=>'P1_TIME_PERIOD,P1_ALL_TIME'
,p_items_value_column_name=>'Y_TOTAL'
,p_items_label_column_name=>'X_PERIOD'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(38674676245329705346)
,p_chart_id=>wwv_flow_imp.id(38674676055818705344)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(38674676341126705347)
,p_chart_id=>wwv_flow_imp.id(38674676055818705344)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38696144106595108146)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38680107773328837048)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(38679791983919836998)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(38680170606298837076)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38674675899595705342)
,p_name=>'P1_TIME_PERIOD'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(38674675947735705343)
,p_item_default=>'Weekly'
,p_prompt=>'Select Time Period'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Weekly;Weekly,Monthly;Monthly,Yearly;Yearly,All TIme;All Time'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>11
,p_grid_column=>1
,p_field_template=>wwv_flow_imp.id(38680166551081837074)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38674676686088705350)
,p_name=>'P1_ALL_TIME'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(38674675947735705343)
,p_prompt=>'All Time'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_begin_on_new_line=>'N'
,p_grid_column=>12
,p_field_template=>wwv_flow_imp.id(38680166551081837074)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'TRUE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38674676474437705348)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_TIME_PERIOD'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38674676592373705349)
,p_event_id=>wwv_flow_imp.id(38674676474437705348)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38674675947735705343)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38772206381020071101)
,p_name=>'New'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_ALL_TIME'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38772206449688071102)
,p_event_id=>wwv_flow_imp.id(38772206381020071101)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38674675947735705343)
);
wwv_flow_imp.component_end;
end;
/
