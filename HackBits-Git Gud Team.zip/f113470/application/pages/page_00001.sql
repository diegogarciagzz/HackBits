prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38480805229426179952
,p_default_application_id=>113470
,p_default_id_offset=>0
,p_default_owner=>'WKSP_GITGUDHACKMTY'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Recover Home Page'
,p_alias=>'RECOVER-HOME-PAGE'
,p_step_title=>'Home Page'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'body {',
'    background-image: url("#APP_FILES#fondo_negro2.jpg");',
unistr('    background-size: cover; /* Ajusta el tama\00F1o de la imagen para cubrir toda la pantalla */'),
'    background-position: center; /* Centra la imagen */',
'    background-repeat: no-repeat; /* Evita que la imagen se repita */',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38444466870448283634)
,p_plug_name=>'To Do List'
,p_title=>'To Do List'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38680085543922837039)
,p_plug_display_sequence=>50
,p_query_type=>'TABLE'
,p_query_table=>'TASKS_HABITS'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'To Do List'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(38444466984622283735)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:60:&SESSION.::&DEBUG.::P60_TITULO,P60_TIPO,P60_FECHA_INICIO,P60_FECHA_FINAL:#TITULO#,#TIPO#,#FECHA_INICIO#,#FECHA_FINAL#'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_owner=>'LUISBOLTECH005@OUTLOOK.COM'
,p_internal_uid=>38444466984622283735
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38444467119392283737)
,p_db_column_name=>'TITULO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Titulo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38444467259241283738)
,p_db_column_name=>'TIPO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38444467303794283739)
,p_db_column_name=>'FECHA_INICIO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fecha Inicio'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38444467409210283740)
,p_db_column_name=>'FECHA_FINAL'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fecha Final'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(38850799561822457580)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'388507996'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TITULO:TIPO:FECHA_INICIO:FECHA_FINAL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38919560173262492205)
,p_plug_name=>'ProfileInfo'
,p_title=>'About'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(38680095302045837042)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>5
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="profile-card">',
'    <div class="profile-info">',
'        <h2 class="profile-name">&APP_USER.</h2>',
'        <p class="profile-role">User Role: Admin</p>',
'        <p class="profile-email">Email: user@example.com</p>',
'    </div>',
'</div>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38919560068243492204)
,p_plug_name=>'Photo'
,p_parent_plug_id=>wwv_flow_imp.id(38919560173262492205)
,p_plug_display_sequence=>10
,p_location=>null
,p_template_component_type=>'PARTIAL'
,p_plug_source_type=>'TMPL_THEME_42$AVATAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'SIZE', 't-Avatar--md',
  'TYPE', 'IMAGE')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38919560205606492206)
,p_plug_name=>'MiniCalendar'
,p_title=>'Calendar'
,p_icon_css_classes=>'fa-calendar-month'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38680095302045837042)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_query_type=>'TABLE'
,p_query_table=>'TASKS_HABITS'
,p_include_rowid_column=>false
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'additional_calendar_views', 'list:navigation',
  'display_column', 'TITULO',
  'end_date_column', 'FECHA_FINAL',
  'event_sorting', 'AUTOMATIC',
  'maximum_events_day', '10',
  'multiple_line_event', 'Y',
  'show_time', 'N',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'FECHA_INICIO')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38444467912997283745)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38444466870448283634)
,p_button_name=>'AddTask'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38680169065095837075)
,p_button_image_alt=>'Add Habit'
,p_button_redirect_url=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:::'
,p_grid_new_row=>'Y'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38950015315953301504)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38444467912997283745)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38950015466047301505)
,p_event_id=>wwv_flow_imp.id(38950015315953301504)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38444466870448283634)
);
wwv_flow_imp.component_end;
end;
/
