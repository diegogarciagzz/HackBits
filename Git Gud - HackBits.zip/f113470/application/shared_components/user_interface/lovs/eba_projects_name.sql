prompt --application/shared_components/user_interface/lovs/eba_projects_name
begin
--   Manifest
--     EBA_PROJECTS.NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38480805229426179952
,p_default_application_id=>113470
,p_default_id_offset=>0
,p_default_owner=>'WKSP_GITGUDHACKMTY'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(38712674088940566856)
,p_lov_name=>'EBA_PROJECTS.NAME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'EBA_PROJECTS'
,p_return_column_name=>'ID'
,p_display_column_name=>'NAME'
,p_default_sort_column_name=>'NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>15569362193919
);
wwv_flow_imp.component_end;
end;
/
