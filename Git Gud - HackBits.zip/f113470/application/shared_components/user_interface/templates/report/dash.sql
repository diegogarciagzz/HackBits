prompt --application/shared_components/user_interface/templates/report/dash
begin
--   Manifest
--     ROW TEMPLATE: DASH
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38480805229426179952
,p_default_application_id=>113470
,p_default_id_offset=>0
,p_default_owner=>'WKSP_GITGUDHACKMTY'
);
wwv_flow_imp_shared.create_row_template(
 p_id=>wwv_flow_imp.id(38706331921430349316)
,p_row_template_name=>'DASH'
,p_internal_name=>'DASH'
,p_row_template1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="container">',
'    <div class="row">',
'    <div class="col-md-3">',
'      <div class="card-counter primary">',
'        <i class="fa fa-code-fork"></i>',
'        <span class="count-numbers">#VALUE1#</span>',
'        <span class="count-name">#LABEL1#</span>',
'      </div>',
'    </div>',
'',
'    <div class="col-md-3">',
'      <div class="card-counter danger">',
'        <i class="fa fa-ticket"></i>',
'        <span class="count-numbers">#VALUE2#</span>',
'        <span class="count-name">#LABEL2#</span>',
'      </div>',
'    </div>',
'',
'    <div class="col-md-3">',
'      <div class="card-counter success">',
'        <i class="fa fa-database"></i>',
'        <span class="count-numbers">#VALUE3#</span>',
'        <span class="count-name">#LABEL3#</span>',
'      </div>',
'    </div>',
'',
'    <div class="col-md-3">',
'      <div class="card-counter info">',
'        <i class="fa fa-users"></i>',
'        <span class="count-numbers">#VALUE4#</span>',
'        <span class="count-name">#LABEL4#</span>',
'      </div>',
'    </div>',
' ',
''))
,p_row_template_before_rows=>'<dl class="t-AVPList #COMPONENT_CSS_CLASSES#" #REPORT_ATTRIBUTES# id="report_#REGION_STATIC_ID#" data-region-id="#REGION_STATIC_ID#">'
,p_row_template_after_rows=>wwv_flow_string.join(wwv_flow_t_varchar2(
'</dl>',
'<table class="t-Report-pagination" role="presentation">#PAGINATION#</table>'))
,p_row_template_type=>'NAMED_COLUMNS'
,p_column_heading_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'<style>',
'.card-counter{',
'    box-shadow: 2px 2px 10px #DADADA;',
'    margin: 5px;',
'    padding: 20px 10px;',
'    background-color: #fff;',
'    height: 100px;',
'    border-radius: 5px;',
'    transition: .3s linear all;',
'  }',
'',
'  .card-counter:hover{',
'    box-shadow: 4px 4px 20px #DADADA;',
'    transition: .3s linear all;',
'  }',
'',
'  .card-counter.primary{',
'    background-color: #007bff;',
'    color: #FFF;',
'  }',
'',
'  .card-counter.danger{',
'    background-color: #ef5350;',
'    color: #FFF;',
'  }  ',
'',
'  .card-counter.success{',
'    background-color: #66bb6a;',
'    color: #FFF;',
'  }  ',
'',
'  .card-counter.info{',
'    background-color: #26c6da;',
'    color: #FFF;',
'  }  ',
'',
'  .card-counter i{',
'    font-size: 5em;',
'    opacity: 0.2;',
'  }',
'',
'  .card-counter .count-numbers{',
'    position: absolute;',
'    right: 35px;',
'    top: 20px;',
'    font-size: 32px;',
'    display: block;',
'  }',
'',
'  .card-counter .count-name{',
'    position: absolute;',
'    right: 35px;',
'    top: 65px;',
'    font-style: italic;',
'    text-transform: capitalize;',
'    opacity: 0.5;',
'    display: block;',
'    font-size: 18px;',
'  }',
'</style>',
'',
'',
'<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">',
'<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>',
'<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>'))
,p_row_template_display_cond1=>'0'
,p_row_template_display_cond2=>'0'
,p_row_template_display_cond3=>'0'
,p_row_template_display_cond4=>'0'
,p_pagination_template=>'<span class="t-Report-paginationText">#TEXT#</span>'
,p_next_page_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a href="#LINK#" class="t-Button t-Button--small t-Button--noUI t-Report-paginationLink t-Report-paginationLink--next">',
'  #PAGINATION_NEXT#<span class="a-Icon icon-right-arrow" aria-hidden="true"></span>',
'</a>'))
,p_previous_page_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a href="#LINK#" class="t-Button t-Button--small t-Button--noUI t-Report-paginationLink t-Report-paginationLink--prev">',
'  <span class="a-Icon icon-left-arrow" aria-hidden="true"></span>#PAGINATION_PREVIOUS#',
'</a>'))
,p_next_set_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a href="#LINK#" class="t-Button t-Button--small t-Button--noUI t-Report-paginationLink t-Report-paginationLink--next">',
'  #PAGINATION_NEXT_SET#<span class="a-Icon icon-right-arrow" aria-hidden="true"></span>',
'</a>'))
,p_previous_set_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<a href="#LINK#" class="t-Button t-Button--small t-Button--noUI t-Report-paginationLink t-Report-paginationLink--prev">',
'  <span class="a-Icon icon-left-arrow" aria-hidden="true"></span>#PAGINATION_PREVIOUS_SET#',
'</a>'))
,p_theme_id=>42
,p_theme_class_id=>7
,p_preset_template_options=>'t-AVPList--leftAligned'
,p_translate_this_template=>'N'
);
wwv_flow_imp.component_end;
end;
/
